SOLO — Daily System v1

What this is:
A free, single-file Solo Leveling-style personal quest dashboard designed around the user's current schedule.

How to use on a computer:
1. Open index.html in a browser.
2. Your XP and quest completion are saved locally in that browser.

How to use on iPhone:
- The simplest route is to open the file from a web host. This prototype itself is static and needs no paid backend.
- For reliable scheduled alerts in this first version, use Apple Reminders/Calendar alongside the dashboard. The next version can add native iPhone notifications.

Important:
- This prototype is intentionally local-only.
- Do not enter sensitive medical information.
- Baseball/training quests are reminders, not medical or training prescriptions.
